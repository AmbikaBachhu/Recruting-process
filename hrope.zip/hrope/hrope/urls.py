"""hrope URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from app import views
from hrope import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index,name="index"),
    path('show/',views.show,name="show"),
    path('save/',views.save,name="save"),
    path('check/',views.check,name="check"),
    path('validate/',views.validate,name="validate"),
    path('main/',views.mains,name="main"),
    path('addemp/',views.addemp,name="addemp"),
    path('saveemp/',views.saveemp,name="saveemp"),
    path('viewemp/',views.viewemp,name="viewemp"),
    path('up/',views.up,name="up"),
    path('update/',views.update,name="update"),
    path('saveup/',views.save_up,name="save_up"),
    path('del/',views.dele,name="del"),
    path('delete/',views.delete,name="delete"),
    path('managerhome/',views.managerhome,name="managerhome"),
    path('manager/',views.manger,name="manger"),
    path('requre/',views.requre,name="requre"),
    path('addreq/',views.addreqt,name="addreq"),
    path('savereq/',views.savereq,name="savereq"),
    path('modify/',views.modify,name="modify"),
    path('get/',views.getdetails,name="getdetails"),
    path('updatereq/',views.updatereq,name="updatereq"),
    path('delreq/',views.delreq,name="delreq"),
    path('deleted/',views.deleted,name="deleted"),
    path('intersp/',views.intersp,name="intersp"),
    path('assigninter/',views.assigninter,name="assign_int"),
    path('addschedule/',views.addschedule,name="add_schedule"),
    path('applicantlog/',views.applog,name="app_log"),
    path('applicant/',views.applicant,name="applicant"),
    path('saveappli/',views.saveappli,name="save_appli"),
    path('appliaply/',views.appliaply,name="appli_aply"),
    path('saveaply/',views.saveaply,name="saveaply"),
    path('interviewer/',views.interviewer,name="interviewer"),
    path('conduct/',views.condeuct,name="conduct"),
    path('savefinal/',views.savefinal,name="save_final"),
    path('hrhead/',views.hrhead,name="hrhead"),
    path('hrhome/',views.hrhome,name="hrhome"),
    path('shortli/',views.shortli,name="shortli"),
    path('saveshortli/',views.saveshortli,name="save_shortli"),
    path('short/',views.short,name="short"),
    path('selected/',views.selected,name="selected"),
    path('rejected/',views.rejected,name="rejected"),
    path('valial/',views.valal,name="val_al"),
    path('valiint/', views.valint, name="val_int"),
    path('valihr/', views.valhr, name="val_hr")

]
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)

