from django import  forms
from app.models import adminlogin,addemplyee,addreq,modreq,interapp,apprf,appapli,interview,shortlist,inthr
from django.core.validators import RegexValidator

alpha = RegexValidator(r'^[a-zA-Z]*$','Only alphabets are allowed')
new = RegexValidator(r'^[6-9]\d{9}$', 'Invalid Contact')



class adminloginform(forms.ModelForm):
    des = (('Manager','MANAGER'),('HRhead','HRHEAD'),('Interviewer','INTERVIEWER'),('Admin','ADMIN'))
    password = forms.CharField(widget=forms.PasswordInput,label="PASSWORD")
    username = forms.CharField(label="USER NAME",validators=[alpha])
    types = forms.ChoiceField(label="TYPE",choices=des)
    class Meta:
        model = adminlogin
        fields = "__all__"


class addemplyform(forms.ModelForm):
    des = (('Manager','MANAGER'),('HRhead','HRHEAD'),('Interviewer','INTERVIEWER'),('Emplyee','EMPLOYEE'))
    password = forms.CharField(widget=forms.PasswordInput, label="PASSWORD")
    ename = forms.CharField(label="EMPLOYEE NAME", validators=[alpha])
    design = forms.ChoiceField(label="DESIGNATION",choices=des)
    add = forms.CharField(label="ADDRESS",widget=forms.Textarea)
    con = forms.CharField(label="CONTACT NO",validators=[new])
    email = forms.EmailField(label="EMAIL ID")

    class Meta:
        model = addemplyee
        fields = "__all__"

class modreqform(forms.ModelForm):
    idno = forms.IntegerField(label="OPPORTUNITY CODE")

    class Meta:
           model = modreq
           fields = "__all__"

class addreqform(forms.ModelForm):
    idno = forms.IntegerField(label="OPPORTUNITY CODE")
    qualify = forms.CharField(label="QUALIFICATION")
    regfrom = forms.DateField(widget=forms.DateInput(attrs={'placeholder':"YYYY-MM-DD"}),label="REGISTRATIONS START_FROM")
    age = forms.IntegerField(label="AGE LIMIT")
    lastdate = forms.DateField(widget=forms.DateInput(attrs={'placeholder':"YYYY-MM-DD"}),label="LAST DATE TO APPLY")
    depid = forms.CharField(label="DEPARTMENT ID")
    nopo = forms.IntegerField(label="NO OF POSITIONS")
    des = forms.CharField(label="DESCRIPTION")
    res = forms.CharField(label="RESPONSIBILITIES")
    con = forms.IntegerField(label="CONTACT",validators=[new])

    class Meta:
        model = addreq
        fields = "__all__"

class interappform(forms.ModelForm):
    selectid = forms.IntegerField(label="SELECT EMP ID")
    sheduledate = forms.DateField(widget=forms.DateInput(attrs={'placeholder':"YYYY-MM-DD"}),label="SCHEDULE DATE")

    class Meta:
        model = interapp
        fields = ["selectid","sheduledate"]

class apprfform(forms.ModelForm):
    gen = (('Male','MALE'),('Female','FEMALE'))
    name = forms.CharField(label="NAME",validators=[alpha])
    dob = forms.DateField(widget=forms.DateInput(attrs={'placeholder':"YYYY-MM-DD"}),label="DATE OF BIRTH")
    email = forms.EmailField(label="EMAIL ID")
    gender = forms.ChoiceField(label="GENDER",widget=forms.RadioSelect,choices=gen)
    mobile = forms.IntegerField(label="MOBILE NO",validators=[new])
    address = forms.CharField(label="ADDRESS")
    user = forms. CharField(label="USER NAME",validators=[alpha])
    password = forms.CharField(widget=forms.PasswordInput,label="PASSWORD")

    class Meta:
        model = apprf
        fields = "__all__"


class appapliform(forms.ModelForm):
    gen = (('Male','MALE'),('Female','FEMALE'))
    po = (('Manager','MANAGER'),('Interviewer','INTERVIEWER'),('Hr head','HR HEAD'))
    name = forms.CharField(label="NAME", validators=[alpha])
    dob = forms.DateField(widget=forms.DateInput(attrs={'placeholder': "YYYY-MM-DD"}), label="DATE OF BIRTH")
    email = forms.EmailField(label="EMAIL ID")
    gender = forms.ChoiceField(label="GENDER", widget=forms.RadioSelect, choices=gen)
    mobile = forms.IntegerField(label="MOBILE NO", validators=[new])
    address = forms.CharField(label="ADDRESS")
    qualification = forms.CharField(label="QUALIFICATION")
    post = forms.ChoiceField(label="POST",choices=po)
    percentage = forms.FloatField(label="PERCENTAGE")
    resume = forms.FileField(label="RESUME")

    class Meta:
        model = appapli
        fields = "__all__"



class interviewform(forms.ModelForm):
    re = (('Selected','SELECTED'),('Rejected','REJECTED'))
    interid = forms.IntegerField(label="INTERVIEW ID")
    interviewer = forms.IntegerField(label="INTERVIEWER")
    schtime = forms.DateField(widget=forms.DateInput(attrs={'placeholder':"YYYY-MM-DD"}),label="SCHEDULE TIME")
    result = forms.ChoiceField(choices=re,label="RESULT")

    class Meta:
        model = interview
        fields = ['interid','interviewer','schtime','result']


class shortlistform(forms.ModelForm):
    appid = forms.IntegerField(label="APPLICANT ID")
    appname = forms.CharField(label="APPLICANT NAME")
    qualification = forms.CharField(label="QUALIFICATION")
    dob = forms.DateField(widget=forms.DateInput(attrs={'placeholder': "YYYY-MM-DD"}), label="DATE OF BIRTH")
    percentage = forms.FloatField(label="PERCENTAGE")
    email = forms.EmailField(label="EMAIL ID")
    mobile = forms.IntegerField(label="MOBILE NO", validators=[new])
    status = forms.CharField(label="STATUS")

    class Meta:
        model = shortlist
        fields = "__all__"



class inthrform(forms.ModelForm):
    username = forms.CharField(label="USER NAME", validators=[alpha])
    password = forms.CharField(widget=forms.PasswordInput, label="PASSWORD")
    types = forms.CharField(widget=forms.HiddenInput)

    class Meta:
        model = inthr
        fields = "__all__"