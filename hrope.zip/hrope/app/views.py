from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt

from app.models import adminlogin,addemplyee,addreq,modreq,interapp,apprf,appapli,interview,shortlist,inthr
from app.forms import adminloginform,addemplyform,addreqform,modreqform,interappform,apprfform,appapliform,interviewform
from app.forms import shortlistform,inthrform
from django.contrib import messages

# Create your views here.


def index(request):
    return render(request, "index.html")


def show(request):
    return render(request, "show.html", {"al": adminloginform()})


def save(request):
    user = request.POST.get("username")
    pa = request.POST.get("password")
    ty = request.POST.get("types")
    adminlogin(username=user, password=pa,types=ty).save()
    messages.success(request, "saved")
    return redirect('show')


def check(request):
    return render(request,"home.html",{"al":adminloginform()})


def validate(request):
    user = request.POST.get("a1")
    pa = request.POST.get("a2")
    ty = request.POST.get("a3")
    try:
         adminlogin.objects.get(username=user,password=pa,types=ty)
         return render(request,"adminhome.html")
    except adminlogin.DoesNotExist :
        return render(request, "show.html", {"al": adminloginform(), "error": "Invalid"})

def mains(request):
    return render(request,"adminhome.html")


def addemp(request):
    return render(request,"addemp.html",{"ae": addemplyform()})

def saveemp(request):
    user = request.POST.get("ename")
    pa = request.POST.get("password")
    des = request.POST.get("design")
    add = request.POST.get("add")
    con = request.POST.get("con")
    email = request.POST.get("email")
    ae = addemplyform(request.POST)
    if ae.is_valid():
        addemplyee(ename=user, password=pa, design=des,  add=add, con=con,email=email).save()
        messages.success(request, "saved")
        return redirect('addemp')
    else:
        return render(request, "addemp.html", {"ae": ae})


def viewemp(request):
    ae = addemplyee.objects.all()
    return render(request,"view_emp.html",{"ae":ae})


def up(request):
    ae = addemplyee.objects.all()
    return render(request, "up_emp.html", {"ae": ae})


def update(request):
    no = request.GET.get("mn")
    ae = addemplyee.objects.get(id=no)
    return render(request,"update_emp.html",{"ae":ae})


def save_up(request):
    no = request.POST.get("c1")
    user = request.POST.get("c2")
    pa = request.POST.get("c3")
    des = request.POST.get("c4")
    add = request.POST.get("c5")
    con = request.POST.get("c6")
    email = request.POST.get("c7")
    addemplyee.objects.filter(id =no).update(ename=user,password=pa,design=des,add=add,con=con,email=email)
    return render(request, "adminhome.html",{"no":no})


def dele(request):
    ae = addemplyee.objects.all()
    return render(request, "del_emp.html", {"ae": ae})

@csrf_exempt
def delete(request,id = None):
    if request.method == 'POST':
      n = request.POST.getlist("item")
      for y in n :
        addemplyee.objects.get(id=y).delete()
      return redirect('del')


def manger(request):
    user = request.POST.get("a1")
    pa = request.POST.get("a2")
    ty = request.POST.get("a3")
    try:
        adminlogin.objects.get(username=user, password=pa,types=ty)
        return render(request, "managerhome.html")
    except adminlogin.DoesNotExist:
            return render(request, "show.html", {"al": adminloginform(), "error": "Invalid"})

def requre(request):
    return render(request,"requre.html")


def addreqt(request):
    return render(request,"addreq.html",{"ar":addreqform()})


def savereq(request):
    no = request.POST.get("idno")
    q = request.POST.get("qualify")
    reg = request.POST.get("regfrom")
    a = request.POST.get("age")
    last = request.POST.get("lastdate")
    dp = request.POST.get("depid")
    np = request.POST.get("nopo")
    de = request.POST.get("des")
    re = request.POST.get("res")
    co = request.POST.get("con")
    ar = addreqform(request.POST)
    if ar.is_valid():
        addreq(idno=no,qualify=q,regfrom=reg,age=a,lastdate=last,depid=dp,nopo=np,des=de,res=re,con=co).save()
        modreq(idno=no).save()
        messages.success(request,"saved")
        return redirect('addreq')
    else:
        return render(request,"addreq.html",{"ar":ar})


def modify(request):
    return render(request,"modify.html",{"mf":modreqform()})


def updatereq(request):
    no = request.POST.get("a1")
    q = request.POST.get("a2")
    a = request.POST.get("a4")
    dp = request.POST.get("a6")
    np = request.POST.get("a7")
    de = request.POST.get("a8")
    re = request.POST.get("a9")
    co = request.POST.get("a10")
    addreq.objects.filter(idno=no).update(idno=no,qualify=q,age=a,depid=dp,nopo=np,des=de,res=re,con=co)
    return render(request,"managerhome.html",{"no":no})


def getdetails(request):
    no = request.POST.get("idno")
    mg = addreq.objects.get(idno=no)
    try:
        modreq.objects.get(idno=no)
        return render(request, "update_req.html", {"no": no,"data":mg})
    except:
        messages.error(request, "Invalid User")
        return redirect('modify')


def delreq(request):
    mg = addreq.objects.all()
    return render(request,"deletereq.html",{"mg":mg})


@csrf_exempt
def deleted(request,id = None):
    if request.method == 'POST':
        n = request.POST.getlist("item")
        for y in n:
            addreq.objects.get(id=y).delete()
            return redirect('delreq')


def intersp(request):
    return render(request,"intershedule.html")


def assigninter(request):
    assign = request.POST.get("applicant")
    return render(request,"assign_inter.html",{"assign":assign,"ai":interappform()})


def addschedule(request):
    app = request.POST.get("a1")
    sch = request.POST.get("selectid")
    sd = request.POST.get("sheduledate")
    interapp(appid=app,selectid=sch,sheduledate=sd).save()
    messages.success(request,"saved")
    return redirect('assign_int')


def applog(request):
    return render(request,"app_log.html",{"al":adminloginform()})


def interviewer(request):
    return render(request,"interviewer.html",{"al":inthrform()})


def hrhead(request):
    return render(request,"hrhead.html",{"al":inthrform()})


def valal(request):
    user = request.POST.get("username")
    pa = request.POST.get("password")
    ty = 'applicant'
    try:
        adminlogin.objects.get(username=user, password=pa,types=ty)
        return redirect('appli_aply')
    except adminlogin.DoesNotExist:
        return render(request, "app_log.html", {"al": adminloginform(), "error": "Invalid"})


def valint(request):
    user = request.POST.get("username")
    pa = request.POST.get("password")
    ty = 'interviewer'
    try:
         inthr.objects.get(username=user, password=pa,types=ty)
         return render(request,"conduct_final.html")
    except inthr.DoesNotExist:
           return render(request, "interviewer.html", {"al": inthrform(), "error": "Invalid"})


def valhr(request):
    user = request.POST.get("username")
    pa = request.POST.get("password")
    ty = 'hrhead'
    try:
        inthr.objects.get(username=user, password=pa, types=ty)
        return render(request,"hrhome.html")
    except inthr.DoesNotExist:
        return render(request, "hrhead.html", {"al": inthrform(), "error": "Invalid"})

def applicant(request):
    return render(request,"applog_home.html",{"arf":apprfform()})


def saveappli(request):
    n = request.POST.get("name")
    d = request.POST.get("dob")
    em = request.POST.get("email")
    ge = request.POST.get("gender")
    mo = request.POST.get("mobile")
    ad = request.POST.get("address")
    us = request.POST.get("user")
    pa = request.POST.get("password")
    sa = apprfform(request.POST)
    if sa.is_valid():
        apprf(name=n,dob=d,email=em,gender=ge,mobile=mo,address=ad,user=us,password=pa).save()
        adminlogin(username=us,password=pa).save()
        messages.success(request,"Saved")
        return redirect('val_al')
    else:
        return render(request,"applog_home.html",{"error":"Invalid"})


def appliaply(request):
    return render(request,"appli_aply.html",{"aa":appapliform()})


def saveaply(request):
    n = request.POST.get("name")
    d = request.POST.get("dob")
    em = request.POST.get("email")
    ge = request.POST.get("gender")
    mo = request.POST.get("mobile")
    ad = request.POST.get("address")
    qu = request.POST.get("qualification")
    po = request.POST.get("post")
    per = request.POST.get("percentage")
    res = request.POST.get("resume")
    sap = appapliform(request.POST)
    if sap.is_valid():
        appapli(name=n,dob=d,email=em,gender=ge,mobile=mo,address=ad,qualification=qu,post=po,percentage=per,resume=res).save()
        messages.success(request, "Saved")
        return redirect('appli_aply')
    else:
        return render(request, "applog_home.html", {"error": "Invalid"})


def condeuct(request):
    assign = request.POST.get("applicant")
    return render(request, "final_inter.html", {"assign": assign, "ai": interviewform()})

def managerhome(request):
    return render(request,"manager login.html")


def savefinal(request):
    app = request.POST.get("a1")
    iid = request.POST.get("interid")
    inter = request.POST.get("interviewer")
    sch = request.POST.get("schtime")
    re = request.POST.get("result")
    interview(appid=app,interid=iid,interviewer=inter,schtime=sch,result=re).save()
    messages.success(request,"saved")
    return redirect('conduct')


def short(request):
    sh = shortlist.objects.all()
    return render(request,"short.html",{"sh":sh})


def hrhome(request):
    return render(request,"hrhome.html")


def shortli(request):
    return render(request,"shortli.html",{"sl":shortlistform()})


def saveshortli(request):
    app = request.POST.get("appid")
    appn = request.POST.get("appname")
    qual = request.POST.get("qualification")
    db = request.POST.get("dob")
    per = request.POST.get("percentage")
    em = request.POST.get("email")
    mo = request.POST.get("mobile")
    sta = request.POST.get("status")
    shortlist(appid=app,appname=appn,qualification=qual,dob=db,percentage=per,email=em,mobile=mo,status=sta).save()
    messages.success(request,"saved")
    return redirect('shortli')


def selected(request):
    se = interview.objects.filter(result="Selected")
    return render(request,"selected.html",{"se":se})


def rejected(request):
    se = interview.objects.filter(result="Rejected")
    return render(request, "rejected.html", {"se": se})