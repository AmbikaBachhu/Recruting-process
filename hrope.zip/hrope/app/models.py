from django.db import models

# Create your models here.
class adminlogin(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    types = models.CharField(max_length=30,default=None)


class addemplyee(models.Model):
    ename = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    design = models.CharField(max_length=30)
    add = models.CharField(max_length=50)
    con = models.IntegerField()
    email = models.EmailField()

    def __str__(self):
        return self.id

class addreq(models.Model):
    idno = models.IntegerField(primary_key=True)
    qualify = models.CharField(max_length=20)
    regfrom = models.DateField()
    age = models.IntegerField()
    lastdate = models.DateField()
    depid = models.CharField(max_length=30)
    nopo = models.IntegerField()
    des = models.CharField(max_length=30)
    res = models.CharField(max_length=30)
    con = models.IntegerField()



class modreq(models.Model):
    idno = models.IntegerField(primary_key=True)


class interapp(models.Model):
    appid = models.IntegerField(primary_key=True)
    selectid = models.IntegerField()
    sheduledate = models.DateField()

class apprf(models.Model):
    name = models.CharField(max_length=30)
    dob = models.DateField()
    email = models.EmailField()
    gender = models.CharField(max_length=10)
    mobile = models.IntegerField()
    address =models.CharField(max_length=50)
    user = models. CharField(max_length=30)
    password = models.CharField(max_length=30)

class appapli(models.Model):
   name = models.CharField(max_length=30)
   dob = models.DateField()
   email = models.EmailField()
   gender = models.CharField(max_length=10)
   mobile = models.IntegerField()
   address = models.CharField(max_length=50)
   qualification = models.CharField(max_length=30)
   post = models.CharField(max_length=10)
   percentage = models.FloatField()
   resume = models.FileField(upload_to='product/')


class interview(models.Model):
    appid = models.IntegerField(primary_key=True)
    interid = models.IntegerField()
    interviewer = models.IntegerField()
    schtime = models.DateField()
    result = models.CharField(max_length=30)

class shortlist(models.Model):
    appid = models.IntegerField(primary_key=True)
    appname = models.CharField(max_length=30)
    qualification = models.CharField(max_length=30)
    dob = models.DateField()
    percentage = models.FloatField()
    email = models.EmailField()
    mobile = models.IntegerField()
    status = models.CharField(max_length=20)

class inthr(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    types = models.CharField(max_length=30)


